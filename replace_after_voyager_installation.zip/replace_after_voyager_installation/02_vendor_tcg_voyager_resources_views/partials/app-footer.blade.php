<footer class="app-footer">
    <div class="site-footer-right">
        Departments of Developmental and Social Psychology
    </div>
</footer>
